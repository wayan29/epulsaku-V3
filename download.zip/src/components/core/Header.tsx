
// src/components/core/Header.tsx
"use client";

import Link from "next/link";
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { Zap, LayoutDashboard, History, LogOut, UserCircle2, Menu, DollarSign, Settings, KeyRound, ShieldCheck, TrendingUp, Shield, ShieldAlert, ShoppingCart, Cog, PackageSearch, BarChart3, Home, Wrench, Contact, Phone, UserCog, UserPlus, FileText, MessageSquare } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetClose, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ModeToggle } from "./ModeToggle";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { ALL_APP_MENUS, AppMenu } from "@/lib/auth-utils";

interface NavLinkProps {
  href: string;
  children: React.ReactNode;
  icon?: React.ReactNode;
  onClick?: () => void;
}

const NavLink = ({ href, children, icon, onClick }: NavLinkProps) => (
  <Button variant="ghost" asChild className="justify-start w-full" onClick={onClick}>
    <Link href={href} className="flex items-center gap-3 py-2 px-2">
      {icon}
      <span className="text-sm">{children}</span>
    </Link>
  </Button>
);

export default function Header() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [isSheetOpen, setIsSheetOpen] = useState(false);

  const handleLogout = async () => {
    logout();
    toast({ title: "Logged Out", description: "You have been successfully logged out." });
  };
  
  const hasAccess = (menuKey: string) => {
    if(!user) return false;
    if(user.role === 'super_admin' || (user.permissions && user.permissions.includes('all_access'))) return true;
    return user.permissions && user.permissions.includes(menuKey);
  }

  const sidebarNavGroups = [
    {
      label: "Utama",
      icon: <Home className="h-5 w-5" />,
      items: ALL_APP_MENUS.filter(m => ['dashboard'].includes(m.key) && hasAccess(m.key))
    },
    {
      label: "Produk",
      icon: <PackageSearch className="h-5 w-5" />,
      items: ALL_APP_MENUS.filter(m => ['layanan_digiflazz', 'layanan_tokovoucher'].includes(m.key) && hasAccess(m.key))
    },
    {
      label: "Riwayat & Laporan",
      icon: <BarChart3 className="h-5 w-5" />,
      items: ALL_APP_MENUS.filter(m => ['riwayat_transaksi', 'laporan_profit'].includes(m.key) && hasAccess(m.key))
    },
    {
      label: "Alat",
      icon: <Wrench className="h-5 w-5" />,
      items: ALL_APP_MENUS.filter(m => ['cek_nickname_game', 'cek_id_pln', 'cek_operator_seluler', 'chat_ai'].includes(m.key) && hasAccess(m.key))
    },
  ];

  const roleDisplayMap: Record<string, string> = {
    'staf': 'Staf',
    'admin': 'Admin',
    'super_admin': 'Super Admin',
  };
  const roleColorMap: Record<string, string> = {
    'staf': 'bg-blue-100 text-blue-800 border-blue-300',
    'admin': 'bg-purple-100 text-purple-800 border-purple-300',
    'super_admin': 'bg-red-100 text-red-800 border-red-300',
  };


  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm">
      <div className="container flex h-16 max-w-screen-2xl items-center justify-between">
        <div className="flex items-center gap-2">
          <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6 text-primary" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[280px] p-4 flex flex-col">
              <SheetHeader className="text-left mb-4 border-b pb-3">
                <SheetTitle className="flex items-center gap-2 text-primary text-xl font-bold font-headline">
                  <Zap className="h-7 w-7" />
                  ePulsaku Menu
                </SheetTitle>
              </SheetHeader>
              
              <nav className="flex-grow flex flex-col gap-1 overflow-y-auto pr-1">
                <Accordion type="multiple" className="w-full" defaultValue={[...sidebarNavGroups.map(g => g.label)]}>
                  {sidebarNavGroups.filter(g => g.items.length > 0).map((group) => {
                    return (
                        <AccordionItem value={group.label} key={group.label} className="border-b-0 mb-1">
                        <AccordionTrigger className="py-2.5 px-2 text-sm font-semibold text-foreground/80 hover:bg-accent/10 rounded-md hover:no-underline">
                            <div className="flex items-center gap-2">
                            {group.icon}
                            {group.label}
                            </div>
                        </AccordionTrigger>
                        <AccordionContent className="pt-1 pb-0 pl-3">
                            <div className="flex flex-col gap-0.5 border-l-2 border-accent/30 pl-3">
                            {group.items.map((item) => (
                                <SheetClose asChild key={`sidebar-${item.href}`} onClick={() => setIsSheetOpen(false)}>
                                <NavLink href={item.href} icon={<Zap className="h-4 w-4"/>}>
                                    {item.label}
                                </NavLink>
                                </SheetClose>
                            ))}
                            </div>
                        </AccordionContent>
                        </AccordionItem>
                    );
                  })}
                </Accordion>
              </nav>

              {user && (
                <div className="mt-auto pt-4 border-t space-y-2">
                   <div className="px-2 mb-2 flex items-center justify-between gap-2 text-sm">
                      <div className="flex flex-col">
                        <span className="font-semibold text-foreground">{user.username}</span>
                        <Badge variant="outline" className={`capitalize text-xs w-fit mt-1 ${roleColorMap[user.role] || 'border-gray-300'}`}>
                           {roleDisplayMap[user.role] || user.role}
                        </Badge>
                      </div>
                      <SheetClose asChild onClick={() => setIsSheetOpen(false)}>
                         <Link href="/account">
                           <Button variant="ghost" size="icon">
                              <Settings className="h-5 w-5" />
                              <span className="sr-only">Account Settings</span>
                           </Button>
                         </Link>
                      </SheetClose>
                   </div>
                  
                    <Button onClick={handleLogout} variant="ghost" className="w-full justify-start text-destructive hover:bg-destructive/10 hover:text-destructive">
                          <LogOut className="mr-3 h-5 w-5" /> Logout
                    </Button>
                </div>
              )}
            </SheetContent>
          </Sheet>

          <Link href="/dashboard" className="flex items-center gap-2 text-primary ml-2">
            <Zap className="h-8 w-8 md:h-7 md:w-7" />
            <span className="text-2xl md:text-xl font-bold font-headline">ePulsaku</span>
          </Link>
        </div>
        <div className="flex items-center gap-2">
            <ModeToggle />
        </div>
      </div>
    </header>
  );
}
