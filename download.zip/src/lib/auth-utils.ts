
// src/lib/auth-utils.ts

// This file contains constants and types related to authentication.
// It does NOT contain any server-side logic and is safe to import into client components.

import jwt from 'jsonwebtoken';

// --- CONSTANTS ---
export const SALT_ROUNDS = 10;
export const JWT_SECRET = process.env.JWT_SECRET;
export const JWT_EXPIRATION = '1d';
export const JWT_REMEMBER_ME_EXPIRATION = '365d';
export const AUTH_COOKIE_NAME = 'ePulsakuAuthToken_v1';
export const MAX_ATTEMPTS = 5;
export const LOCKOUT_PERIOD_MS = 2 * 60 * 1000;

// --- TYPES & INTERFACES ---
export type UserRole = 'staf' | 'admin' | 'super_admin';

export interface User {
  id: string;
  username: string;
  role: UserRole;
  permissions: string[]; // Added user-specific permissions
}

export interface StoredUser {
  _id: string;
  username: string;
  email?: string;
  hashedPassword?: string;
  hashedPin?: string;
  role: UserRole;
  permissions: string[]; // Added user-specific permissions
  createdBy?: string;
  telegramChatId?: string;
  isDisabled?: boolean;
  failedPinAttempts?: number;
}

export interface LoginActivity {
  _id: string;
  userId: string;
  username: string;
  loginTimestamp: Date;
  userAgent?: string;
  ipAddress?: string;
}

export interface UserUpdatePayload {
    email?: string;
    role?: UserRole;
    permissions?: string[];
    newPassword?: string;
    newPin?: string;
    telegramChatId?: string;
}

// Function to generate a JWT
export function generateToken(user: User, rememberMe?: boolean): string {
    if (!JWT_SECRET) {
      throw new Error("JWT_SECRET is not configured on the server.");
    }
    const payload = {
        userId: user.id,
        username: user.username,
        role: user.role,
        permissions: user.permissions, // Include permissions in the token
    };
    const expiresIn = rememberMe ? JWT_REMEMBER_ME_EXPIRATION : JWT_EXPIRATION;
    return jwt.sign(payload, JWT_SECRET, { expiresIn });
}

// --- Menu Permissions ---
export interface AppMenu {
    key: string;
    href: string;
    label: string;
    description: string;
    roles?: ('admin' | 'staf')[]; // Optional: for default roles if needed
}

export const ALL_APP_MENUS: AppMenu[] = [
  { key: 'dashboard', href: '/dashboard', label: 'Dashboard', description: 'Halaman ringkasan utama.' },
  { key: 'layanan_digiflazz', href: '/layanan/digiflazz', label: 'Layanan Digiflazz', description: 'Akses produk dari Digiflazz.' },
  { key: 'layanan_tokovoucher', href: '/order/tokovoucher', label: 'Layanan TokoVoucher', description: 'Akses produk dari TokoVoucher.' },
  { key: 'riwayat_transaksi', href: '/transactions', label: 'Riwayat Transaksi', description: 'Lihat semua log transaksi.' },
  { key: 'laporan_profit', href: '/profit-report', label: 'Laporan Profit & Statement', description: 'Analisis keuntungan dan detail transaksi.' },
  { key: 'cek_nickname_game', href: '/tools/game-nickname-checker', label: 'Cek Nickname Game', description: 'Alat bantu cek ID game.' },
  { key: 'cek_id_pln', href: '/tools/pln-checker', label: 'Cek ID Pelanggan PLN', description: 'Alat bantu cek ID PLN.' },
  { key: 'cek_operator_seluler', href: '/tools/operator-checker', label: 'Cek Operator Seluler', description: 'Alat bantu cek nomor HP.' },
  { key: 'chat_ai', href: '/tools/chat', label: 'Chat AI Gemini', description: 'Asisten AI untuk membantu Anda.' },
  { key: 'pengaturan_akun', href: '/account', label: 'Pengaturan Akun & Keamanan', description: 'Ganti password, PIN, dll.' },
  { key: 'pengaturan_admin', href: '/admin-settings', label: 'Pengaturan Kredensial Admin', description: 'Kelola API Key provider.' },
  { key: 'pengaturan_harga_digiflazz', href: '/price-settings', label: 'Pengaturan Harga Digiflazz', description: 'Set harga jual produk Digiflazz.' },
  { key: 'pengaturan_harga_tokovoucher', href: '/tokovoucher-price-settings', label: 'Pengaturan Harga TokoVoucher', description: 'Set harga jual produk TokoVoucher.' },
  { key: 'manajemen_pengguna', href: '/management/users', label: 'Manajemen Pengguna', description: 'Tambah atau kelola staf/admin.', roles: ['super_admin'] },
];
