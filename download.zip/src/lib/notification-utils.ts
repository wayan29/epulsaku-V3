// src/lib/notification-utils.ts
'use server';

import { getAdminSettingsFromDB } from './admin-settings-utils';
import { sendTelegramMessage } from '@/ai/flows/send-telegram-message-flow';
import { getUserByUsername, type StoredUser } from './user-utils';

export interface TelegramNotificationDetails {
  refId: string;
  productName: string;
  customerNoDisplay: string;
  status: string;
  provider: 'Digiflazz' | 'TokoVoucher' | 'System' | string;
  costPrice?: number;
  sellingPrice?: number;
  profit?: number;
  sn?: string | null;
  failureReason?: string | null;
  timestamp: Date;
  additionalInfo?: string;
  trxId?: string;
  transactedBy?: string; // Username of who made the transaction
}

// This is a local helper function, not exported.
function escapeTelegramReservedChars(text: string | number | null | undefined): string {
  if (text === null || typeof text === 'undefined') return '';
  const str = String(text);
  // Escape all reserved characters for MarkdownV2
  return str.replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1');
}

// This function now handles both transaction and security alert notifications
function formatTelegramNotificationMessage(details: TelegramNotificationDetails): string {
  // Check if it's a security alert based on provider or a specific productName
  if (details.provider === 'System' || details.productName === 'Account Security Alert') {
     let alertMessage = `*🚨 Peringatan Keamanan Akun ePulsaku*\n\n`;
     alertMessage += `*Pengguna:* ${escapeTelegramReservedChars(details.transactedBy)}\n`;
     alertMessage += `*Status:* *${escapeTelegramReservedChars(details.status)}*\n`;
     if(details.failureReason) {
       alertMessage += `*Alasan:* ${escapeTelegramReservedChars(details.failureReason)}\n`;
     }
     alertMessage += `\n_Waktu: ${escapeTelegramReservedChars(new Date(details.timestamp).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }))}_`;
     return alertMessage;
  }
  
  // Default to transaction notification format
  let message = `*🔔 Transaksi ePulsaku ${details.additionalInfo ? `(${escapeTelegramReservedChars(details.additionalInfo)})` : ''}*\n\n`;
  if (details.transactedBy) {
    message += `*Oleh:* ${escapeTelegramReservedChars(details.transactedBy)}\n`;
  }
  message += `*Provider:* ${escapeTelegramReservedChars(details.provider)}\n`;
  message += `*ID Ref:* \`${escapeTelegramReservedChars(details.refId)}\`\n`;
  if (details.trxId) {
    message += `*ID Trx Provider:* \`${escapeTelegramReservedChars(details.trxId)}\`\n`;
  }
  message += `*Produk:* ${escapeTelegramReservedChars(details.productName)}\n`;
  message += `*Tujuan:* ${escapeTelegramReservedChars(details.customerNoDisplay)}\n`;
  message += `*Status:* *${escapeTelegramReservedChars(details.status)}*\n`;

  if (details.status.toLowerCase().includes('sukses')) {
    message += `*SN/Token:* \`${details.sn ? escapeTelegramReservedChars(details.sn) : 'N/A'}\`\n`;
    if (typeof details.sellingPrice === 'number') {
      message += `*Harga Jual:* Rp ${escapeTelegramReservedChars(details.sellingPrice.toLocaleString('id-ID'))}\n`;
    }
    if (typeof details.costPrice === 'number') {
      message += `*Harga Modal:* Rp ${escapeTelegramReservedChars(details.costPrice.toLocaleString('id-ID'))}\n`;
    }
    if (typeof details.profit === 'number' && details.profit !== 0) {
      message += `*Profit:* Rp ${escapeTelegramReservedChars(details.profit.toLocaleString('id-ID'))}\n`;
    }
  } else if (details.status.toLowerCase().includes('gagal') && details.failureReason) {
    message += `*Alasan Gagal:* ${escapeTelegramReservedChars(details.failureReason)}\n`;
  } else if (details.status.toLowerCase().includes('pending')) {
    message += `_Transaksi sedang diproses\\.\\._\n`;
  }

  message += `\n_${escapeTelegramReservedChars(new Date(details.timestamp).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }))}_`;
  return message;
}

export async function trySendTelegramNotification(details: TelegramNotificationDetails) {
  try {
    const adminSettings = await getAdminSettingsFromDB();
    const botToken = adminSettings.telegramBotToken;
    const globalChatIdsString = adminSettings.telegramChatId;

    if (!botToken) {
      // console.warn('Telegram Bot Token not configured. Skipping all notifications for Ref ID:', details.refId);
      return;
    }

    const messageContent = formatTelegramNotificationMessage(details);
    const chatIdsToSendTo = new Set<string>();

    // 1. Add global admin chat IDs
    if (globalChatIdsString) {
      globalChatIdsString.split(',').map(id => id.trim()).filter(id => id).forEach(id => chatIdsToSendTo.add(id));
    }

    // 2. Add user-specific chat ID if available (only for transaction notifications, not for security alerts to admin)
    if (details.provider !== 'System' && details.transactedBy) {
      const user = await getUserByUsername(details.transactedBy);
      if (user && user.telegramChatId) {
        chatIdsToSendTo.add(user.telegramChatId);
      }
    }

    if (chatIdsToSendTo.size === 0) {
      // console.warn('No Telegram Chat IDs configured (neither global nor for the user). Skipping notification for Ref ID:', details.refId);
      return;
    }

    // 3. Send notifications
    for (const chatId of chatIdsToSendTo) {
      const result = await sendTelegramMessage({ botToken, chatId, message: messageContent });
      if (result.success) {
        console.log(`Telegram notification sent to Chat ID ${chatId} for event regarding user: ${details.transactedBy || details.refId}`);
      } else {
        console.warn(`Failed to send Telegram notification to Chat ID ${chatId} for event regarding user ${details.transactedBy || details.refId}: ${result.message}`);
      }
    }
  } catch (error) {
    console.error('Error in trySendTelegramNotification for event:', details, error);
  }
}
