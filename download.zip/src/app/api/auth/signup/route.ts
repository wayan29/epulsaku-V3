// src/app/api/auth/signup/route.ts
import { NextResponse } from 'next/server';
import { createUser } from '@/lib/user-utils';

export async function POST(req: Request) {
  try {
    const { username, email, password, pin } = await req.json();

    if (!username || !email || !password || !pin) {
      return NextResponse.json({ message: 'All fields are required.' }, { status: 400 });
    }

    // Server action already checks if users exist. It will assign 'super_admin' to the first user.
    const result = await createUser({
      username: username,
      email: email,
      passwordPlain: password,
      pinPlain: pin,
      role: 'super_admin' // This will only apply if it's the first user, as per the logic in createUser
    });

    if (result.success) {
      // Don't set a cookie on signup, force them to log in.
      return NextResponse.json({ success: true, user: result.user });
    } else {
      return NextResponse.json({ message: result.message || "Could not create account." }, { status: 409 }); // 409 Conflict for existing user
    }
  } catch (error) {
    console.error('API Signup Error:', error);
    return NextResponse.json({ message: 'An internal server error occurred.' }, { status: 500 });
  }
}
