// src/app/api/auth/logout/route.ts
import { NextResponse } from 'next/server';
import { AUTH_COOKIE_NAME } from '@/lib/auth-utils';
import { serialize } from 'cookie';

export async function POST() {
  // To log out, we tell the browser to expire the cookie immediately.
  const serializedCookie = serialize(AUTH_COOKIE_NAME, '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: -1, // Expire immediately
  });

  const response = NextResponse.json({ success: true, message: "Logged out successfully." });
  response.headers.set('Set-Cookie', serializedCookie);
  
  return response;
}
