// src/ai/flows/chat-flow.ts
'use server';
/**
 * @fileOverview A stateless Genkit flow for a simple chat interaction.
 * This flow does not retain any memory of past conversations.
 */

import { ai } from '@/ai/genkit';
import { z } from 'zod';

// ======== Chat Flow Schema ========
const ChatInputSchema = z.object({
  userId: z.string().default('demo-user').describe("A unique identifier for the user."),
  message: z.string().describe('The user\'s message to the AI.'),
  model: z.string().optional().describe('The AI model to use for the response.'),
});
export type ChatInput = z.infer<typeof ChatInputSchema>;

const ChatOutputSchema = z.object({
  response: z.string().describe('The AI\'s response.'),
});
export type ChatOutput = z.infer<typeof ChatOutputSchema>;

// ======== Main Chat Flow ========
export async function chatWithGemini(input: ChatInput): Promise<ChatOutput> {
  return chatFlow(input);
}

const chatFlow = ai.defineFlow(
  {
    name: 'chatFlow',
    inputSchema: ChatInputSchema,
    outputSchema: ChatOutputSchema,
  },
  async ({ userId, message, model }) => {
    
    const systemInstruction = `Anda adalah asisten AI yang ramah dan membantu bernama ePulsaku AI. Tujuan Anda adalah membantu pengguna secara akurat dan ringkas.`;

    const llmResponse = await ai.generate({
        model: model || 'googleai/gemini-2.5-flash',
        prompt: message,
        config: {
            systemInstruction: systemInstruction,
        }
    });

    const answer = llmResponse.text;

    return { response: answer };
  }
);